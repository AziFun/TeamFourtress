<?xml version="1.0" encoding="UTF-8"?>
<tileset version="1.2" tiledversion="1.2.0" name="Pipes-RustyWalls" tilewidth="32" tileheight="32" tilecount="88" columns="8">
 <image source="images/Skorpio's Pack/Pipes-RustyWalls.png" width="256" height="352"/>
</tileset>
