<?xml version="1.0" encoding="UTF-8"?>
<tileset version="1.2" tiledversion="1.2.0" name="rpg_maker_vx_rtp_tileset_by_telles0808" tilewidth="32" tileheight="32" tilecount="2016" columns="32">
 <image source="images/rpg_maker_vx_rtp_tileset_by_telles0808.png" width="1024" height="2016"/>
</tileset>
